<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP is: <strong>{{ $otp }}</strong></p>
    <p>Use this code to reset your password.</p>
</body>
</html>
