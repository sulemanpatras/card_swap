<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP is: <strong><?php echo e($otp); ?></strong></p>
    <p>Use this code to reset your password.</p>
</body>
</html>
<?php /**PATH /home/alisonstech/Downloads/Card/resources/views/emails/otp.blade.php ENDPATH**/ ?>